package com.spring_tuesday.user_service.repository;

import com.spring_tuesday.user_service.model.UserEntity;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Service
public class CustomUserRepositoryImpl implements CustomUserRepository {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public UserEntity customFind(Long id) {
        return (UserEntity) entityManager.createQuery("SELECT u FROM UserEntity u WHERE u.id = :id")
                .setParameter("id", id)
                .getSingleResult();

    }

}
