package com.spring_tuesday.user_service.controller;

import com.spring_tuesday.user_service.model.UserEntity;
import com.spring_tuesday.user_service.repository.UserRepository;
import org.apache.catalina.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {
    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/users")
    List<UserEntity> findAll() {
       return userRepository.findAll();
    }

    @GetMapping("/user/{id}")
   UserEntity findById(@PathVariable Long id) {
        return userRepository.customFind(id);
    }


}

