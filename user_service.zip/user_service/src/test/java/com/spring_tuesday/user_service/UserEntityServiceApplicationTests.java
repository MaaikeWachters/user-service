package com.spring_tuesday.user_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserEntityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
